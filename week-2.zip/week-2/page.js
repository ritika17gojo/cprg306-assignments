export default function Page() {
    return (
        <main>
            <h1>Shopping List</h1>
        </main>
    );
}

import StudentInfo from '.../week-2/student-info';
export default function Week2Page() {
    return (
        <div>
            <h1>Week 2</h1>
            <Student Info />
        </div>
    );
}