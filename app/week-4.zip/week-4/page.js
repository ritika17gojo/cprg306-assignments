import NewItem from './new-item';

function Week4Page() {
  return (
    <div className="min-h-screen container mx-auto px-4">
      <h1 className="text-xl font-bold text-center my-6">Add New Item to Shopping List</h1>
      <NewItem />
    </div>
  );
}

export default Week4Page;
